package com.dwt;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigInteger;

import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.security.spec.ECFieldFp;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPrivateKeySpec;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.EllipticCurve;
import java.security.Signature;
import java.security.SignedObject;

import com.ecc.Encryption;


public class KeyPairs {
	EllipticCurve curve;
	ECParameterSpec spec;
	ECPrivateKeySpec priKey;
	ECPublicKeySpec pubKey;
	PrivateKey getPri;
	PublicKey getPub;
	KeyPair pair;
	KeyPairGenerator g;
	String privateK;
	String publicK;
	String sign;
	String getP;
	SignedObject signO;
	Key myKey;
	String m;
	int[] b;
	Encryption enc;
	String serNme;

	public KeyPairs() {

		Security
				.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		initValue();
		getKeyPair();
	}

	public void initValue() {
		curve = new EllipticCurve(
				new ECFieldFp(
						new BigInteger(
								"883423532389192164791648750360308885314476597252960362792450860609699839")), // q
				new BigInteger(
						"7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc",
						16), // a
				new BigInteger(
						"6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a",
						16)); // b

		spec = new ECParameterSpec(
				curve,
				new ECPoint(
						new BigInteger(
								"5b6dc53bc61a2548ffb0f671472de6c9521a9d2d2534e65abfcbd5fe0c70",
								16),
						new BigInteger(
								"7fd9f1ed2e65f09f6ce0893baf5e8e31e6ae82ea8c3592335be906d38dee",
								16)), // G
				new BigInteger(
						"883423532389192164791648750360308884807550341691627752275345424702807307"), // n
				1); // h
	}

	public void getKeyPair() {
		try {
			g = KeyPairGenerator.getInstance("ECDSA", "BC");
			g.initialize(spec, new SecureRandom());
			callGen();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
		}
	}

	public void callGen() {
		pair = g.generateKeyPair();
		getPri = pair.getPrivate();
	}

	public String getPrivate() {

		return getOriginal(getPri.toString());
	}

	public String getPublic() {

		return String.valueOf(pair.getPublic());
	}

	public String getOriginal(String getP) {
		String priv = getP.substring(46);
		return priv;
	}

	public void Encr(String str, String serverName) {
		serNme = serverName;
		enc = new Encryption();
		b = enc.ecies_ex(str);

	}

	private String getString(byte[] b2) {
		// TODO Auto-generated method stub
		String s = "";
		for (int i = 0; i < b2.length; i++) {
			s += b2[i];
		}
		return s;
	}

	public String getSign(String msg) {
		m = msg;
		try {
			callGen();
			signO = new SignedObject(te(msg), getPri, Signature.getInstance(
					"ECDSA", "BC"));
			byte[] b = signO.getSignature();
			sign = getString(b);
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (SignatureException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sign;
	}

	public Serializable te(String msg) {
		Serializable si = msg;
		return si;
	}
}