package com.dwt;

import java.io.Serializable;

public class Data implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public byte[] data;
	public String file;
	public int[] sign;
}
