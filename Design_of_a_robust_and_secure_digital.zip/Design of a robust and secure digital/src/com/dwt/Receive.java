package com.dwt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Vector;

import javax.swing.JOptionPane;

import com.design.Authentication;
import com.design.Chennal;

public class Receive extends Thread {

	private Socket soc;
	private ServerSocket serSoc;
	private ObjectInputStream ois;
	int port;
	Chennal chennal;
	Action action;
	public Data data;

	boolean flag;
	int len;

	public Receive(Chennal chennal, int port, Action action) {
		this.chennal = chennal;
		this.port = port;
		this.action = action;
		start();
	}

	public void run() {
		try {
			receive();
		} catch (Exception e) {
		}
	}

	public void receive() {
		try {
			serSoc = new ServerSocket(port);
			while (true) {
				soc = serSoc.accept();
				ois = new ObjectInputStream(soc.getInputStream());
				String str = (String) ois.readObject();
				checkStatus(str);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void checkStatus(String str) {
		try {
			if (str.equals("RTS")) {

				Vector<String> path = (Vector<String>) ois.readObject();
				String dest = (String) ois.readObject();
				if (chennal.source.equals(dest)) {
					path.add(chennal.source);
					sendCTS(path);

				} else {
					path.add(chennal.source);
					chennal.action.routing(path, dest);
				}

			} else if (str.equals("CTS")) {
				Vector<String> path = (Vector<String>) ois.readObject();
				String fPath = "";
				for (int i = 0; i < path.size(); i++) {
					if (i < path.size() - 1)
						fPath += path.get(i) + "->";
					else
						fPath += path.get(i);
				}
				chennal.dftQue.addRow(new Object[] { fPath });
				if (!flag) {
					flag = true;
					chennal.lblShortestPath.setText(fPath);
					len = fPath.length();
				} else {
					if (len > fPath.length())
						chennal.lblShortestPath.setText(fPath);
				}
			} else if (str.equals("Data")) {
				try {
					JOptionPane.showMessageDialog(null, "Image Received");
					data = (Data) ois.readObject();
					System.out.println("data.file:" + data.file);
					saveImage();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void sendCTS(Vector<String> path) {
		// TODO Auto-generated method stub
		try {

			int nPort = chennal.action.getPort(path.get(0));
			Socket socket = new Socket("localhost", nPort);
			ObjectOutputStream oos = new ObjectOutputStream(socket
					.getOutputStream());
			oos.writeObject("CTS");
			oos.writeObject(path);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void saveImage() {
		// TODO Auto-generated method stub
		byte[] b = data.data;
		String filename = data.file;
		try {
			File file = new File("ReceivedEmbImages\\" + filename);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(b);
			recImgPath=file.getAbsolutePath();
			Authentication authentication = new Authentication();
			authentication.txtPath.setText(file.getAbsolutePath());
			authentication.init(this);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String recImgPath;
}
