package com.dwt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import javax.swing.JTextArea;

public class Action {

	public String getVerificationCode(String path) {
		// TODO Auto-generated method stub
		String str = "";
		try {
			File file = new File(path);
			str = file.getName();
			str = str.substring(0, str.lastIndexOf("."));
			str = VerificationCode.calculateCode(str, str);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}

	public String getVerifiCode(String path) {
		// TODO Auto-generated method stub
		String str = "";
		try {
			str = VerificationCode.calculateCode(path, path + path);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}
	public boolean getStatus() {
		boolean flag = false;
		try {
			Properties p1 = new Properties();
			FileInputStream fis = new FileInputStream("Attacker.properties");
			p1.load(fis);
			String sta = p1.getProperty("attack");
			if (sta.equals("true"))
				flag = true;
		} catch (Exception ea) {
			ea.printStackTrace();
		}
		return flag;
	}


	KeyPairs keys = new KeyPairs();

	public String getSource() {
		// TODO Auto-generated method stub
		return new SourceAndPort().getSource();
	}

	public int getPort() {
		// TODO Auto-generated method stub
		return new SourceAndPort().getPort();
	}

	public void setProperty(String file, String source, String text) {
		// TODO Auto-generated method stub
		try {
			Properties properties = new Properties();
			FileOutputStream fos = new FileOutputStream(file, true);
			properties.setProperty(source, text);
			properties.store(fos, source);
			fos.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	Vector<String> neigh = new Vector<String>();

	public void setNeighbour(JTextArea jtaNeigh, String source) {
		// TODO Auto-generated method stub
		try {
			Properties properties = new Properties();
			FileInputStream fis = new FileInputStream("Distance.properties");
			properties.load(fis);
			fis.close();
			int mydis = Integer.parseInt(properties.getProperty(source));
			Enumeration<Object> em = properties.keys();
			while (em.hasMoreElements()) {
				String key = (String) em.nextElement();
				int dis = Integer.parseInt(properties.getProperty(key));
				int min = mydis - 50;
				int max = mydis + 50;
				if ((!key.equals(source)) && dis >= min && dis <= max) {
					neigh.add(key);
					jtaNeigh
							.append(key + " ["
									+ getProperty("Publickey.properties", key)
									+ " ]\n");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void routing(Vector<String> path, String dest) {
		// TODO Auto-generated method stub

		try {
			for (int i = 0; i < neigh.size(); i++) {
				String nei = neigh.get(i);
				if (getAvailable(path, nei)) {
					int nPort = getPort(nei);
					Socket socket = new Socket("localhost", nPort);
					ObjectOutputStream oos = new ObjectOutputStream(socket
							.getOutputStream());
					oos.writeObject("RTS");
					oos.writeObject(path);
					oos.writeObject(dest);
				}
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getProperty(String file, String key) {
		// TODO Auto-generated method stub
		String value = "";
		try {
			Properties properties = new Properties();
			FileInputStream fis = new FileInputStream(file);
			properties.load(fis);
			fis.close();
			value = properties.getProperty(key);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	private boolean getAvailable(Vector<String> path, String nei) {
		// TODO Auto-generated method stub
		return !path.contains(nei);
	}

	public int getPort(String nei) {
		// TODO Auto-generated method stub
		int mydis = 0;
		try {
			Properties properties = new Properties();
			FileInputStream fis = new FileInputStream("Ports.properties");
			properties.load(fis);
			fis.close();
			mydis = Integer.parseInt(properties.getProperty(nei));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mydis;
	}

	public void sendData(String dest, Data data) {
		// TODO Auto-generated method stub
		try {
			int nPort = getPort(dest);
			Socket socket = new Socket("localhost", nPort);
			ObjectOutputStream oos = new ObjectOutputStream(socket
					.getOutputStream());
			oos.writeObject("Data");
			oos.writeObject(data);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getPublicKey() {
		// TODO Auto-generated method stub
		return keys.getPublic();
	}

	public String getPrivateKey() {
		// TODO Auto-generated method stub
		return keys.getPrivate();
	}

	public int getDistance() {
		// TODO Auto-generated method stub
		return new SourceAndPort().getDistance();
	}
}
